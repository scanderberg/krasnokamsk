<?php
/**
* ReadyScript (http://readyscript.ru)
*
* @copyright Copyright (c) ReadyScript lab. (http://readyscript.ru)
* @license http://readyscript.ru/licenseAgreement/
*/
namespace RS\Html\Table\Type\Action;

class Minus extends AbstractAction
{
    protected
        $class_ajax = 'crud-add',
        $class_action = 'minus';
}
