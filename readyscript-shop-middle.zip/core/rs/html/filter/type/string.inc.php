<?php
/**
* ReadyScript (http://readyscript.ru)
*
* @copyright Copyright (c) ReadyScript lab. (http://readyscript.ru)
* @license http://readyscript.ru/licenseAgreement/
*/
namespace RS\Html\Filter\Type;

/**
* @deprecated Вместо данного класса необходимо использовать \RS\Html\Filter\Type\Text
* Данный класс будет удален в последующих версиях
*/
class String extends Text
{}

