<?php
/**
* ReadyScript (http://readyscript.ru)
*
* @copyright Copyright (c) ReadyScript lab. (http://readyscript.ru)
* @license http://readyscript.ru/licenseAgreement/
*/
namespace RS\Orm\Type;

/**
* @deprecated Вместо данного класса необходимо использовать \RS\Orm\Type\Varchar.
* Текущий класс будет удален в последующих версиях
*/
class String extends Varchar
{}  